> npm install
> ng serve