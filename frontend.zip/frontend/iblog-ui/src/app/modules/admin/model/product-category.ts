export class ProductCategory {
    name: String;
    description: String;
}
