export class Product {
    productId: String;
    name: String;
    description: String;
    price: Number
    categoryId: Number;
}