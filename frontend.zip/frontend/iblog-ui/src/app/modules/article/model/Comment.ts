export class Comment {
    id: number;
    comment: string;
}
