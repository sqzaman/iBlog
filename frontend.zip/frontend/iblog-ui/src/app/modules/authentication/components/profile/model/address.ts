export class Address {
    id: number;
    street: string;
    city: string;
    zip: string;
    state: string;
    country: string;	
    addressType: number;
}