export class Credentials {
    usernameOrEmail: string;
    password: string;
}