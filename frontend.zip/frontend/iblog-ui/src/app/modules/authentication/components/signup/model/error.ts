export class Error{
    defaultMessage: string
}