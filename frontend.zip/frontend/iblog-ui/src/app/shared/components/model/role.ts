export class Role {
    authority: any;
}