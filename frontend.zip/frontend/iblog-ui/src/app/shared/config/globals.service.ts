import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  BASE_API_URL: string = 'http://localhost:8080/api/';
  BASE_URL: string = 'http://localhost:4200/api/';
}